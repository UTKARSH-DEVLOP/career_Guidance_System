const express = require("express")
const path = require("path")
const router = express.Router()

// Serve HTML pages
router.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public", "index.html"))
})

router.get("/riasec-test", (req, res) => {
  res.sendFile(path.join(__dirname, "../public", "riasec-test.html"))
})

router.get("/skill-gap", (req, res) => {
  res.sendFile(path.join(__dirname, "../public", "skill-gap.html"))
})

router.get("/skill-gap-result", (req, res) => {
  res.sendFile(path.join(__dirname, "../public", "skill-gap-result.html"))
})

router.get("/job-finder", (req, res) => {
  res.sendFile(path.join(__dirname, "../public", "job-finder.html"))
})

router.get("/mock-interview", (req, res) => {
  res.sendFile(path.join(__dirname, "../public", "mock-interview.html"))
})

router.get("/chat", (req, res) => {
  res.sendFile(path.join(__dirname, "../public", "chat.html"))
})

router.get("/career-form", (req, res) => {
  res.sendFile(path.join(__dirname, "../public", "career-form.html"))
})

module.exports = router
