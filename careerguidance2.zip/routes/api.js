const express = require("express")
const router = express.Router()
const axios = require("axios")

// Career guidance API
router.post("/career", async (req, res) => {
  try {
    const userData = req.body

    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "google/gemini-2.0-flash-exp:free",
        messages: [
          { role: "system", content: "You are a career advisor." },
          { role: "user", content: `Suggest careers based on this student data: ${JSON.stringify(userData)}` },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    )

    if (!response.data.choices || !response.data.choices[0]?.message?.content) {
      console.error("Invalid response structure:", response.data)
      return res.status(500).json({ error: "Invalid AI response structure" })
    }

    const suggestion = response.data.choices[0].message.content
    res.json({ suggestion })
  } catch (error) {
    console.error("Career suggestion error:", error)
    res.status(500).json({ error: "Failed to fetch career guidance" })
  }
})

// New API endpoint for career recommendations
router.post("/career-recommendations", async (req, res) => {
  try {
    const userProfile = req.body

    // Create a detailed prompt for the LLM
    const prompt = `
    You are a professional career counselor. Based on the following user profile, provide detailed career and course recommendations:
    
    User Profile:
    - Name: ${userProfile.name}
    - Age: ${userProfile.age}
    - Education History:
    ${userProfile.educationHistory
      .map(
        (edu) =>
          `  * ${edu.course} in ${edu.stream} from ${edu.institution} (${edu.startDate} to ${edu.endDate}) with ${edu.percentage}% score`,
      )
      .join("\n")}
    ${
      userProfile.interests.length > 0
        ? `- Areas of Interest: ${userProfile.interests.join(", ")}`
        : "- No specific interests mentioned"
    }
    
    Please provide:
    1. 3-5 recommended career paths based on their education and interests
    2. Specific courses or certifications they should pursue to enhance their career prospects
    3. Skills they should develop
    4. A 5-year career progression plan
    
    Format your response in a clear, structured way with headings and bullet points.
    `

    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "google/gemini-2.0-flash-exp:free",
        messages: [{ role: "user", content: prompt }],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    )

    if (!response.data.choices || !response.data.choices[0]?.message?.content) {
      console.error("Invalid response structure:", response.data)
      return res.status(500).json({ error: "Invalid AI response structure" })
    }

    const recommendation = response.data.choices[0].message.content
    res.json({ recommendation })
  } catch (error) {
    console.error("Career recommendation error:", error)
    res.status(500).json({ error: "Failed to generate career recommendations" })
  }
})

// Chat API endpoint
router.post("/chat", async (req, res) => {
  try {
    const { message } = req.body

    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "google/gemini-2.0-flash-exp:free",
        messages: [
          {
            role: "system",
            content:
              "You are a helpful career advisor assistant. Provide concise, accurate information about careers, education paths, job markets, and professional development. Focus on being practical and actionable in your advice.",
          },
          { role: "user", content: message },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    )

    if (!response.data.choices || !response.data.choices[0]?.message?.content) {
      console.error("Invalid response structure:", response.data)
      return res.status(500).json({ error: "Invalid AI response structure" })
    }

    const botResponse = response.data.choices[0].message.content
    res.json({ response: botResponse })
  } catch (error) {
    console.error("Chat API error:", error)
    res.status(500).json({ error: "Failed to process chat message" })
  }
})

// Authentication API
router.post("/authenticate", (req, res) => {
  const { mobile, password } = req.body
  const fakeUsers = [
    { mobile: "9876543210", password: "test123" },
    { mobile: "1234567890", password: "helloWorld" },
  ]

  const user = fakeUsers.find((u) => u.mobile === mobile)
  if (!user) return res.status(401).json({ message: "Not subscribed to premium" })
  if (user.password !== password) return res.status(401).json({ message: "Incorrect password, please try again" })
  res.status(200).json({ message: "Login successful" })
})

// RIASEC Test API
router.post("/submit", async (req, res) => {
  try {
    const scores = req.body.scores
    const prompt = `Suggest 3 best career options for a person with these RIASEC scores:
    Realistic: ${scores.R.toFixed(2)}, Investigative: ${scores.I.toFixed(2)},
    Artistic: ${scores.A.toFixed(2)}, Social: ${scores.S.toFixed(2)},
    Enterprising: ${scores.E.toFixed(2)}, Conventional: ${scores.C.toFixed(2)}.
    Provide a brief explanation for each.`

    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "google/gemini-2.0-flash-exp:free",
        messages: [{ role: "user", content: prompt }],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    )

    res.json({ suggestion: response.data.choices[0].message.content })
  } catch (err) {
    console.error("RIASEC error:", err.response?.data || err.message)
    res.status(500).json({ error: "LLM API error" })
  }
})

// Skill Gap Analysis API
router.post("/analyze-skills", async (req, res) => {
  // Check for API key before making the request
  if (!process.env.OPENROUTER_API_KEY) {
    console.error("OPENROUTER_API_KEY is missing in environment variables.")
    return res.status(500).json({ error: "Server misconfiguration: API key missing." })
  }
  try {
    const { technicalSkills, softSkills } = req.body

    console.log(technicalSkills)
    const userPrompt = `
    Given the following technical and soft skills, suggest 5 suitable job roles.
    
    For each job role, return a JSON object that includes:
    1. "having skills" – skills (technical and soft) the user already possesses relevant to the role.
    2. "missing skills" – additional skills (technical and soft) the user would need for that role.
    3. "explanation" – a short summary of why this role fits the user's current skills.
    4. "learning path" – a step-by-step learning plan (3–5 steps) to help the user acquire the missing skills based on their current skills.
    
    User's Technical Skills: ${technicalSkills.join(", ") || "None"}
    User's Soft Skills: ${softSkills.join(", ") || "None"}
    
    Return your entire response in this exact JSON format:
    
    {
      "Job Role 1": {
        "having skills": {
          "technical": [],
          "soft": []
        },
        "missing skills": {
          "technical": [],
          "soft": []
        },
        "explanation": "Short explanation here.",
        "learning path": [
          "Step 1: ...",
          "Step 2: ...",
          "Step 3: ..."
        ]
      },
      ...
    }
    
    Important:
    - Only return valid JSON.
    - Do not include any markdown or explanatory text before or after the JSON.
    `

    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "google/gemini-2.0-flash-exp:free",
        messages: [
          {
            role: "user",
            content: userPrompt,
          },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    )

    if (
      !response.data ||
      !response.data.choices ||
      !Array.isArray(response.data.choices) ||
      !response.data.choices[0] ||
      !response.data.choices[0].message ||
      !response.data.choices[0].message.content
    ) {
      console.error("Unexpected response structure from OpenRouter:", response.data)
      return res.status(500).json({ error: "Unexpected response from AI service" })
    }

    let raw = response.data.choices[0].message.content

    // Strip markdown wrapping like ```json or ```
    raw = raw
      .trim()
      .replace(/^```json|^```|```$/g, "")
      .trim()

    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch (err) {
      console.error("Malformed JSON from AI:", raw)
      return res.status(500).json({
        error: "AI returned malformed JSON",
        raw,
      })
    }

    console.log(parsed)

    res.json(parsed)
  } catch (err) {
    if (err.response && err.response.status === 401) {
      console.error("OpenRouter API returned 401 Unauthorized. Check your API key.")
      return res.status(500).json({ error: "External API authentication failed. Check your API key." })
    }
    console.error("Server error:", err.message)
    res.status(500).json({ error: "Server error" })
  }
})

// Job Search API
router.get("/jobs", async (req, res) => {
  const { title = "", location = "", job_type = "", remote = "false" } = req.query
  try {
    const response = await axios.get("https://jsearch.p.rapidapi.com/search", {
      params: {
        query: `${title} ${job_type} ${remote === "true" ? "Remote" : ""} ${location}`.trim(),
        page: 1,
        num_pages: 1,
      },
      headers: {
        "X-RapidAPI-Key": process.env.RAPIDAPI_KEY,
        "X-RapidAPI-Host": "jsearch.p.rapidapi.com",
      },
    })
    res.json(response.data.data)
  } catch (error) {
    console.error("Job search error:", error.message)
    res.status(500).json({ error: "Failed to fetch jobs" })
  }
})

// Mock Interview API
router.post("/interview", async (req, res) => {
  try {
    const {
      action,
      role,
      difficulty,
      question,
      answer,
      questionNumber,
      previousQuestions,
      previousAnswers,
      chatHistory,
      feedbackHistory,
      totalScore,
    } = req.body

    let prompt = ""

    if (action === "generate_interview_question") {
      prompt = `You are an expert interviewer for the role of ${role}. 
      Generate a ${difficulty} level interview question for a candidate. 
      This is question number ${questionNumber} in the interview.
      
      ${
        previousQuestions && previousQuestions.length > 0
          ? `Previous questions asked: ${JSON.stringify(previousQuestions)}
        
        Previous answers given: ${JSON.stringify(previousAnswers)}`
          : "This is the first question of the interview."
      }
      
      The question should be relevant to the role, appropriate for the difficulty level, and not repeat previous questions.
      
      Return only the question text without any additional explanation or formatting.`
    } else if (action === "evaluate_answer") {
      prompt = `You are an expert interviewer for the role of ${role}.
      Evaluate the candidate's answer to the following interview question:
      
      Question: "${question}"
      
      Answer: "${answer}"
      
      Provide your evaluation in the following JSON format:
      {
        "score": [a score from 1-10],
        "feedback": [brief feedback on the answer],
        "strengths": [array of strengths in the answer],
        "areas_for_improvement": [array of areas that could be improved]
      }
      
      Return only valid JSON without any additional text.`
    } else if (action === "generate_interview_summary") {
      prompt = `You are an expert interviewer for the role of ${role}.
      Generate a comprehensive summary of the candidate's interview performance.
      
      Interview details:
      - Role: ${role}
      - Difficulty level: ${difficulty}
      - Total questions: ${chatHistory.length}
      - Total score: ${totalScore} out of ${chatHistory.length * 10}
      
      Chat history:
      ${JSON.stringify(chatHistory)}
      
      Feedback history:
      ${JSON.stringify(feedbackHistory)}
      
      Provide your summary in the following JSON format:
      {
        "overallScore": [percentage score from 0-100],
        "strengths": [array of the candidate's main strengths],
        "weaknesses": [array of the candidate's main weaknesses],
        "improvementAreas": [array of specific recommendations for improvement]
      }
      
      Return only valid JSON without any additional text.`
    }

    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "google/gemini-2.0-flash-exp:free",
        messages: [
          { role: "system", content: "You are an expert interviewer and career advisor." },
          { role: "user", content: prompt },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    )

    if (!response.data.choices || !response.data.choices[0]?.message?.content) {
      console.error("Invalid response structure:", response.data)
      return res.status(500).json({ error: "Invalid AI response structure" })
    }

    const suggestion = response.data.choices[0].message.content
    res.json({ suggestion })
  } catch (error) {
    console.error("Interview API error:", error)
    res.status(500).json({ error: "Failed to process request" })
  }
})

module.exports = router
