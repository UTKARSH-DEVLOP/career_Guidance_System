require("dotenv").config()
console.log("OPENROUTER_API_KEY:", process.env.OPENROUTER_API_KEY)
const express = require("express")
const cors = require("cors")
const path = require("path")
const apiRoutes = require("./routes/api")
const pageRoutes = require("./routes/pages")

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Serve static files
app.use(express.static(path.join(__dirname, "public")))

// API Routes
app.use("/api", apiRoutes)

// Page Routes
app.use("/", pageRoutes)

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`)
})
