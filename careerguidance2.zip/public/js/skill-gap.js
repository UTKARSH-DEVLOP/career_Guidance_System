document.addEventListener("DOMContentLoaded", () => {
  // Predefined skills
  const predefinedTechSkills = [
    "HTML",
    "CSS",
    "JavaScript",
    "Python",
    "React",
    "Node.js",
    "SQL",
    "Java",
    "TypeScript",
    "PHP",
    "C#",
    "Swift",
    "Kotlin",
    "Go",
    "Ruby",
    "AWS",
    "Docker",
    "Kubernetes",
    "Git",
    "GraphQL",
    "MongoDB",
    "Firebase",
    "Redux",
    "Vue.js",
    "Angular",
    "Flutter",
    "TensorFlow",
    "Machine Learning",
    "Data Analysis",
    "GenAI",
  ]

  const predefinedSoftSkills = [
    "Communication",
    "Teamwork",
    "Problem Solving",
    "Time Management",
    "Leadership",
    "Adaptability",
    "Critical Thinking",
    "Creativity",
    "Emotional Intelligence",
    "Conflict Resolution",
    "Negotiation",
    "Public Speaking",
    "Decision Making",
    "Stress Management",
    "Work Ethic",
    "Attention to Detail",
    "Customer Service",
  ]

  // DOM elements
  const newTechSkillInput = document.getElementById("new-tech-skill")
  const newSoftSkillInput = document.getElementById("new-soft-skill")
  const addTechSkillBtn = document.getElementById("add-tech-skill")
  const addSoftSkillBtn = document.getElementById("add-soft-skill")
  const selectedTechSkillsContainer = document.getElementById("selected-tech-skills")
  const selectedSoftSkillsContainer = document.getElementById("selected-soft-skills")
  const availableTechSkillsContainer = document.getElementById("available-tech-skills")
  const availableSoftSkillsContainer = document.getElementById("available-soft-skills")
  const analyzeButton = document.getElementById("analyze-button")
  const analyzeText = document.getElementById("analyze-text")
  const analyzeSpinner = document.getElementById("analyze-spinner")

  // State
  const techSkills = [...predefinedTechSkills]
  const softSkills = [...predefinedSoftSkills]
  let selectedTechSkills = []
  let selectedSoftSkills = []

  // Initialize
  function init() {
    renderAvailableTechSkills()
    renderAvailableSoftSkills()

    // Event listeners
    addTechSkillBtn.addEventListener("click", addTechSkill)
    addSoftSkillBtn.addEventListener("click", addSoftSkill)
    newTechSkillInput.addEventListener("keydown", (e) => e.key === "Enter" && addTechSkill())
    newSoftSkillInput.addEventListener("keydown", (e) => e.key === "Enter" && addSoftSkill())
    analyzeButton.addEventListener("click", analyzeSkills)

    // Check if there's a selected career from previous analysis
    const selectedCareer = sessionStorage.getItem("selectedCareer")
    if (selectedCareer) {
      // Could pre-select some skills based on the career
      console.log("Previously selected career:", selectedCareer)
    }
  }

  // Render available technical skills
  function renderAvailableTechSkills() {
    availableTechSkillsContainer.innerHTML = ""

    techSkills
      .filter((skill) => !selectedTechSkills.includes(skill))
      .forEach((skill) => {
        const badge = createSkillBadge(skill, "tech", false)
        availableTechSkillsContainer.appendChild(badge)
      })
  }

  // Render available soft skills
  function renderAvailableSoftSkills() {
    availableSoftSkillsContainer.innerHTML = ""

    softSkills
      .filter((skill) => !selectedSoftSkills.includes(skill))
      .forEach((skill) => {
        const badge = createSkillBadge(skill, "soft", false)
        availableSoftSkillsContainer.appendChild(badge)
      })
  }

  // Render selected technical skills
  function renderSelectedTechSkills() {
    selectedTechSkillsContainer.innerHTML = ""

    if (selectedTechSkills.length === 0) {
      selectedTechSkillsContainer.innerHTML =
        '<p class="text-sm text-gray-500 dark:text-gray-400">No skills selected</p>'
      return
    }

    selectedTechSkills.forEach((skill) => {
      const badge = createSkillBadge(skill, "tech", true)
      selectedTechSkillsContainer.appendChild(badge)
    })
  }

  // Render selected soft skills
  function renderSelectedSoftSkills() {
    selectedSoftSkillsContainer.innerHTML = ""

    if (selectedSoftSkills.length === 0) {
      selectedSoftSkillsContainer.innerHTML =
        '<p class="text-sm text-gray-500 dark:text-gray-400">No skills selected</p>'
      return
    }

    selectedSoftSkills.forEach((skill) => {
      const badge = createSkillBadge(skill, "soft", true)
      selectedSoftSkillsContainer.appendChild(badge)
    })
  }

  // Create a skill badge
  function createSkillBadge(skill, type, isSelected) {
    const badge = document.createElement("span")

    if (isSelected) {
      badge.className =
        "inline-flex items-center px-2 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300"
      badge.innerHTML = `
          ${skill}
          <button class="ml-1 rounded-full hover:bg-purple-200 dark:hover:bg-purple-800 p-1">
            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        `

      // Add event listener to remove button
      badge.querySelector("button").addEventListener("click", () => {
        if (type === "tech") {
          selectedTechSkills = selectedTechSkills.filter((s) => s !== skill)
          renderSelectedTechSkills()
          renderAvailableTechSkills()
        } else {
          selectedSoftSkills = selectedSoftSkills.filter((s) => s !== skill)
          renderSelectedSoftSkills()
          renderAvailableSoftSkills()
        }

        updateAnalyzeButton()
      })
    } else {
      badge.className =
        "inline-flex items-center px-2 py-1 rounded-full text-sm font-medium border border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
      badge.textContent = skill

      // Add event listener to add skill
      badge.addEventListener("click", () => {
        if (type === "tech") {
          selectedTechSkills.push(skill)
          renderSelectedTechSkills()
          renderAvailableTechSkills()
        } else {
          selectedSoftSkills.push(skill)
          renderSelectedSoftSkills()
          renderAvailableSoftSkills()
        }

        updateAnalyzeButton()
      })
    }

    return badge
  }

  // Add a new technical skill
  function addTechSkill() {
    const skill = newTechSkillInput.value.trim()

    if (skill && !techSkills.includes(skill)) {
      techSkills.push(skill)
      newTechSkillInput.value = ""
      renderAvailableTechSkills()
    }
  }

  // Add a new soft skill
  function addSoftSkill() {
    const skill = newSoftSkillInput.value.trim()

    if (skill && !softSkills.includes(skill)) {
      softSkills.push(skill)
      newSoftSkillInput.value = ""
      renderAvailableSoftSkills()
    }
  }

  // Update analyze button state
  function updateAnalyzeButton() {
    analyzeButton.disabled = selectedTechSkills.length === 0 && selectedSoftSkills.length === 0
  }

  // Analyze skills
  async function analyzeSkills() {
    if (selectedTechSkills.length === 0 && selectedSoftSkills.length === 0) {
      alert("Please select at least one skill.")
      return
    }

    // Show loading state
    analyzeButton.disabled = true
    analyzeText.textContent = "Analyzing..."
    analyzeSpinner.classList.remove("hidden")

    try {
      const response = await fetch("/api/analyze-skills", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          technicalSkills: selectedTechSkills,
          softSkills: selectedSoftSkills,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to analyze skills")
      }

      const data = await response.json()

      // Store results in sessionStorage
      sessionStorage.setItem("careerSuggestions", JSON.stringify(data))

      // Redirect to results page
      window.location.href = "/skill-gap-result.html"
    } catch (error) {
      console.error("Error analyzing skills:", error)
      alert("An error occurred while analyzing your skills. Please try again.")

      // Reset button state
      analyzeButton.disabled = false
      analyzeText.textContent = "Get Career Suggestions"
      analyzeSpinner.classList.add("hidden")
    }
  }

  // Initialize
  init()
})
