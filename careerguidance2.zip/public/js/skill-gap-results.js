document.addEventListener("DOMContentLoaded", () => {
  // DOM elements
  const loadingContainer = document.getElementById("loading-container")
  const resultsContainer = document.getElementById("results-container")
  const noDataContainer = document.getElementById("no-data-container")
  const careerList = document.getElementById("career-list")
  const careerDetails = document.getElementById("career-details")

  // State
  let suggestions = {}
  let selectedCareer = ""

  // Initialize
  function init() {
    // Get data from sessionStorage
    const storedData = sessionStorage.getItem("careerSuggestions")

    if (!storedData) {
      // Show no data message
      loadingContainer.classList.add("hidden")
      noDataContainer.classList.remove("hidden")
      return
    }

    try {
      suggestions = JSON.parse(storedData)

      // Show results
      loadingContainer.classList.add("hidden")
      resultsContainer.classList.remove("hidden")

      // Render career list
      renderCareerList()

      // Select first career by default
      if (Object.keys(suggestions).length > 0) {
        selectedCareer = Object.keys(suggestions)[0]
        renderCareerDetails()
      }
    } catch (error) {
      console.error("Error parsing stored data:", error)
      loadingContainer.classList.add("hidden")
      noDataContainer.classList.remove("hidden")
    }
  }

  // Render career list
  function renderCareerList() {
    careerList.innerHTML = ""

    Object.keys(suggestions).forEach((career) => {
      const button = document.createElement("button")
      button.className = `w-full text-left px-4 py-2 rounded-md mb-2 ${
        selectedCareer === career
          ? "bg-purple-600 text-white"
          : "border border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
      }`
      button.textContent = career

      button.addEventListener("click", () => {
        selectedCareer = career
        renderCareerList()
        renderCareerDetails()
      })

      careerList.appendChild(button)
    })
  }

  // Render career details
  function renderCareerDetails() {
    if (!selectedCareer) return

    const career = suggestions[selectedCareer]

    careerDetails.innerHTML = `
        <h2 class="text-2xl font-bold mb-4">${selectedCareer}</h2>
        <p class="text-gray-600 dark:text-gray-400 mb-6">${career.explanation}</p>
        
        <div class="mb-6">
          <ul class="flex space-x-2 border-b border-gray-200 dark:border-gray-700" role="tablist">
            <li>
              <button class="px-4 py-2 font-medium border-b-2 border-purple-600 text-purple-600 dark:text-purple-400 dark:border-purple-400" role="tab" aria-selected="true" data-tab="skills">
                Skills Analysis
              </button>
            </li>
            <li>
              <button class="px-4 py-2 font-medium text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300" role="tab" aria-selected="false" data-tab="learning">
                Learning Path
              </button>
            </li>
            <li>
              <button class="px-4 py-2 font-medium text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300" role="tab" aria-selected="false" data-tab="jobs">
                Find Jobs
              </button>
            </li>
          </ul>
          
          <div class="pt-4">
            <!-- Skills Tab -->
            <div id="skills-tab" class="tab-content">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 class="text-lg font-semibold mb-3 flex items-center">
                    <svg class="w-5 h-5 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    Skills You Have
                  </h3>
                  <div class="space-y-3">
                    <div>
                      <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Technical:</h4>
                      <div class="flex flex-wrap gap-2">
                        ${
                          career["having skills"].technical.length > 0
                            ? career["having skills"].technical
                                .map(
                                  (skill) =>
                                    `<span class="px-2 py-1 rounded-full text-xs font-medium border border-green-300 bg-green-100/30 text-green-800 dark:border-green-800 dark:bg-green-900/20 dark:text-green-400">${skill}</span>`,
                                )
                                .join("")
                            : '<p class="text-sm text-gray-500 dark:text-gray-400">No matching technical skills</p>'
                        }
                      </div>
                    </div>
                    <div>
                      <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Soft:</h4>
                      <div class="flex flex-wrap gap-2">
                        ${
                          career["having skills"].soft.length > 0
                            ? career["having skills"].soft
                                .map(
                                  (skill) =>
                                    `<span class="px-2 py-1 rounded-full text-xs font-medium border border-green-300 bg-green-100/30 text-green-800 dark:border-green-800 dark:bg-green-900/20 dark:text-green-400">${skill}</span>`,
                                )
                                .join("")
                            : '<p class="text-sm text-gray-500 dark:text-gray-400">No matching soft skills</p>'
                        }
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 class="text-lg font-semibold mb-3 flex items-center">
                    <svg class="w-5 h-5 mr-2 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    Skills to Develop
                  </h3>
                  <div class="space-y-3">
                    <div>
                      <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Technical:</h4>
                      <div class="flex flex-wrap gap-2">
                        ${
                          career["missing skills"].technical.length > 0
                            ? career["missing skills"].technical
                                .map(
                                  (skill) =>
                                    `<span class="px-2 py-1 rounded-full text-xs font-medium border border-red-300 bg-red-100/30 text-red-800 dark:border-red-800 dark:bg-red-900/20 dark:text-red-400">${skill}</span>`,
                                )
                                .join("")
                            : '<p class="text-sm text-gray-500 dark:text-gray-400">No missing technical skills</p>'
                        }
                      </div>
                    </div>
                    <div>
                      <h4 class="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Soft:</h4>
                      <div class="flex flex-wrap gap-2">
                        ${
                          career["missing skills"].soft.length > 0
                            ? career["missing skills"].soft
                                .map(
                                  (skill) =>
                                    `<span class="px-2 py-1 rounded-full text-xs font-medium border border-red-300 bg-red-100/30 text-red-800 dark:border-red-800 dark:bg-red-900/20 dark:text-red-400">${skill}</span>`,
                                )
                                .join("")
                            : '<p class="text-sm text-gray-500 dark:text-gray-400">No missing soft skills</p>'
                        }
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Learning Path Tab -->
            <div id="learning-tab" class="tab-content hidden">
              <h3 class="text-lg font-semibold mb-4">Recommended Learning Path</h3>
              <ol class="space-y-3 pl-5 list-decimal">
                ${career["learning path"].map((step) => `<li class="pl-2">${step}</li>`).join("")}
              </ol>
            </div>
            
            <!-- Jobs Tab -->
            <div id="jobs-tab" class="tab-content hidden">
              <div class="text-center py-4">
                <h3 class="text-lg font-semibold mb-4">Find Jobs for ${selectedCareer}</h3>
                <p class="text-gray-600 dark:text-gray-400 mb-6">
                  Discover job opportunities that match your skills and career aspirations.
                </p>
                <button id="find-jobs-button" class="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 flex items-center mx-auto">
                  <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                  </svg>
                  Browse Job Listings
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div class="flex justify-between mt-6">
          <a href="/skill-gap" class="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700">
            Back to Skill Analysis
          </a>
          <button id="download-button" class="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 flex items-center">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
            </svg>
            Download Report
          </button>
        </div>
      `

    // Add event listeners for tabs
    careerDetails.querySelectorAll('[role="tab"]').forEach((tab) => {
      tab.addEventListener("click", () => {
        // Update tab styles
        careerDetails.querySelectorAll('[role="tab"]').forEach((t) => {
          t.classList.remove("border-purple-600", "text-purple-600", "dark:text-purple-400", "dark:border-purple-400")
          t.classList.add("text-gray-500", "dark:text-gray-400", "hover:text-gray-700", "dark:hover:text-gray-300")
          t.setAttribute("aria-selected", "false")
        })

        tab.classList.remove("text-gray-500", "dark:text-gray-400", "hover:text-gray-700", "dark:hover:text-gray-300")
        tab.classList.add("border-purple-600", "text-purple-600", "dark:text-purple-400", "dark:border-purple-400")
        tab.setAttribute("aria-selected", "true")

        // Show selected tab content
        const tabId = tab.getAttribute("data-tab")
        careerDetails.querySelectorAll(".tab-content").forEach((content) => {
          content.classList.add("hidden")
        })
        careerDetails.querySelector(`#${tabId}-tab`).classList.remove("hidden")
      })
    })

    // Add event listener for find jobs button
    const findJobsButton = careerDetails.querySelector("#find-jobs-button")
    if (findJobsButton) {
      findJobsButton.addEventListener("click", () => {
        sessionStorage.setItem("selectedCareer", selectedCareer)
        window.location.href = "/job-finder"
      })
    }

    // Add event listener for download button
    const downloadButton = careerDetails.querySelector("#download-button")
    if (downloadButton) {
      downloadButton.addEventListener("click", downloadReport)
    }
  }

  // Download report
  function downloadReport() {
    if (!selectedCareer) return

    const career = suggestions[selectedCareer]

    // Create text content
    let content = `Career Path: ${selectedCareer}\n\n`
    content += `Explanation: ${career.explanation}\n\n`

    content += "Skills You Already Have:\n"
    career["having skills"].technical.forEach((skill) => {
      content += `- ${skill} (Technical)\n`
    })
    career["having skills"].soft.forEach((skill) => {
      content += `- ${skill} (Soft)\n`
    })
    content += "\n"

    content += "Skills You Need to Develop:\n"
    career["missing skills"].technical.forEach((skill) => {
      content += `- ${skill} (Technical)\n`
    })
    career["missing skills"].soft.forEach((skill) => {
      content += `- ${skill} (Soft)\n`
    })
    content += "\n"

    content += "Recommended Learning Path:\n"
    career["learning path"].forEach((step, index) => {
      content += `${index + 1}. ${step}\n`
    })

    // Create and download file
    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${selectedCareer.replace(/\s+/g, "_")}_career_path.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Initialize
  init()
})
