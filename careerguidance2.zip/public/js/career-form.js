document.addEventListener("DOMContentLoaded", () => {
  // DOM elements
  const careerForm = document.getElementById("career-form")
  const addEducationButton = document.getElementById("add-education")
  const educationContainer = document.getElementById("education-container")
  const submitButton = document.getElementById("submit-button")
  const submitText = document.getElementById("submit-text")
  const submitSpinner = document.getElementById("submit-spinner")
  const resultsSection = document.getElementById("results-section")
  const recommendationsContent = document.getElementById("recommendations-content")
  const downloadRecommendationsButton = document.getElementById("download-recommendations")
  const newFormButton = document.getElementById("new-form")

  // Initialize
  function init() {
    // Event listeners
    addEducationButton.addEventListener("click", addEducationEntry)
    careerForm.addEventListener("submit", handleFormSubmit)
    downloadRecommendationsButton.addEventListener("click", downloadRecommendations)
    newFormButton.addEventListener("click", resetForm)
  }

  // Add a new education entry
  function addEducationEntry() {
    const entryTemplate = `
      <div class="education-entry bg-gray-50 dark:bg-gray-700/30 p-4 rounded-lg mb-4 relative">
        <button type="button" class="remove-education absolute top-2 right-2 text-gray-500 hover:text-red-500 dark:text-gray-400 dark:hover:text-red-400">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </button>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Course/Degree</label>
            <input type="text" name="course[]" required class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Stream/Specialization</label>
            <input type="text" name="stream[]" required class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
          </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Start Date</label>
            <input type="month" name="start_date[]" required class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">End Date</label>
            <input type="month" name="end_date[]" required class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Percentage/CGPA</label>
            <input type="text" name="percentage[]" required class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Institution Name</label>
          <input type="text" name="institution[]" required class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
        </div>
      </div>
    `

    // Create a temporary container to hold the template
    const tempContainer = document.createElement("div")
    tempContainer.innerHTML = entryTemplate

    // Get the education entry element
    const entryElement = tempContainer.firstElementChild

    // Add event listener to remove button
    entryElement.querySelector(".remove-education").addEventListener("click", () => {
      educationContainer.removeChild(entryElement)
    })

    // Add the entry to the container
    educationContainer.appendChild(entryElement)

    // Scroll to the new entry
    entryElement.scrollIntoView({ behavior: "smooth", block: "center" })
  }

  // Handle form submission
  async function handleFormSubmit(e) {
    e.preventDefault()

    // Show loading state
    submitButton.disabled = true
    submitText.textContent = "Processing..."
    submitSpinner.classList.remove("hidden")

    // Collect form data
    const formData = new FormData(careerForm)

    // Create education history array
    const educationHistory = []
    const courses = formData.getAll("course[]")
    const streams = formData.getAll("stream[]")
    const startDates = formData.getAll("start_date[]")
    const endDates = formData.getAll("end_date[]")
    const percentages = formData.getAll("percentage[]")
    const institutions = formData.getAll("institution[]")

    for (let i = 0; i < courses.length; i++) {
      educationHistory.push({
        course: courses[i],
        stream: streams[i],
        startDate: startDates[i],
        endDate: endDates[i],
        percentage: percentages[i],
        institution: institutions[i],
      })
    }

    // Calculate age from DOB
    const dob = new Date(formData.get("dob"))
    const today = new Date()
    let age = today.getFullYear() - dob.getFullYear()
    const monthDiff = today.getMonth() - dob.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      age--
    }

    // Create user profile object
    const userProfile = {
      name: formData.get("name"),
      dob: formData.get("dob"),
      age: age,
      educationHistory: educationHistory,
      interests: formData
        .get("interests")
        .split(",")
        .map((item) => item.trim())
        .filter((item) => item),
    }

    try {
      // Send data to API
      const response = await fetch("/api/career-recommendations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userProfile),
      })

      if (!response.ok) {
        throw new Error("Failed to get recommendations")
      }

      const data = await response.json()

      // Display recommendations
      displayRecommendations(data.recommendation, userProfile)
    } catch (error) {
      console.error("Error getting recommendations:", error)
      alert("An error occurred while getting recommendations. Please try again.")
    } finally {
      // Reset button state
      submitButton.disabled = false
      submitText.textContent = "Get Recommendations"
      submitSpinner.classList.add("hidden")
    }
  }

  // Display recommendations
  function displayRecommendations(recommendation, userProfile) {
    // Hide form and show results
    careerForm.parentElement.classList.add("hidden")
    resultsSection.classList.remove("hidden")

    // Format the recommendation text with HTML
    const formattedRecommendation = recommendation
      .replace(/\n\n/g, "</p><p>")
      .replace(/\n/g, "<br>")
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")

    // Add user profile summary
    const profileSummary = `
      <div class="mb-6 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
        <h3 class="text-lg font-semibold mb-2">Your Profile Summary</h3>
        <p><strong>Name:</strong> ${userProfile.name}</p>
        <p><strong>Age:</strong> ${userProfile.age}</p>
        <p><strong>Education:</strong> ${userProfile.educationHistory
          .map(
            (edu) => `${edu.course} in ${edu.stream} (${edu.startDate.substring(0, 4)}-${edu.endDate.substring(0, 4)})`,
          )
          .join(", ")}</p>
        ${
          userProfile.interests.length > 0
            ? `<p><strong>Interests:</strong> ${userProfile.interests.join(", ")}</p>`
            : ""
        }
      </div>
    `

    // Set the content
    recommendationsContent.innerHTML = profileSummary + `<p>${formattedRecommendation}</p>`

    // Scroll to results
    resultsSection.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  // Download recommendations
  function downloadRecommendations() {
    const content = recommendationsContent.innerText
    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)

    const a = document.createElement("a")
    a.href = url
    a.download = "career_recommendations.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Reset form
  function resetForm() {
    careerForm.reset()

    // Clear all education entries except the first one
    const entries = educationContainer.querySelectorAll(".education-entry")
    for (let i = 1; i < entries.length; i++) {
      educationContainer.removeChild(entries[i])
    }

    // Show form and hide results
    careerForm.parentElement.classList.remove("hidden")
    resultsSection.classList.add("hidden")

    // Scroll to top
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  // Initialize
  init()
})
