document.addEventListener("DOMContentLoaded", () => {
  // DOM elements
  const step1 = document.getElementById("step-1")
  const step2 = document.getElementById("step-2")
  const chatSection = document.getElementById("chat-section")
  const reportSection = document.getElementById("report-section")
  const resumeInput = document.getElementById("resume-input")
  const roleInput = document.getElementById("role-input")
  const continueButton = document.getElementById("continue-button")
  const startButton = document.getElementById("start-button")
  const difficultySelect = document.getElementById("difficulty")
  const chatBox = document.getElementById("chat-box")
  const answerInput = document.getElementById("answer-input")
  const submitAnswerButton = document.getElementById("submit-answer")
  const reportContent = document.getElementById("report-content")
  const downloadReportButton = document.getElementById("download-report")
  const newInterviewButton = document.getElementById("new-interview")
  const summaryDashboard = document.getElementById("summary-dashboard")

  // State
  let role = ""
  let difficulty = ""
  let resumeData = ""
  let currentQuestion = ""
  const chatHistory = []
  let totalScore = 0
  let questionCount = 0
  let interviewComplete = false
  const feedbackHistory = []

  // Initialize
  function init() {
    // Event listeners
    continueButton.addEventListener("click", goToStep2)
    startButton.addEventListener("click", startInterview)
    submitAnswerButton.addEventListener("click", submitAnswer)
    downloadReportButton.addEventListener("click", downloadReport)
    newInterviewButton.addEventListener("click", () => window.location.reload())

    // Handle file input
    resumeInput.addEventListener("change", handleFileInput)

    // Handle Ctrl+Enter in textarea
    answerInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && e.ctrlKey) {
        submitAnswer()
      }
    })
  }

  // Handle file input
  function handleFileInput(e) {
    const file = e.target.files[0]
    if (!file) return

    // Show file name
    const label = resumeInput.nextElementSibling
    label.innerHTML = `
        <svg class="w-12 h-12 mx-auto mb-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
        </svg>
        <span class="block">${file.name}</span>
        <span class="text-sm text-gray-500 dark:text-gray-500 mt-1 block">Click to change file</span>
      `

    // Read file
    const reader = new FileReader()
    reader.onload = (e) => {
      resumeData = e.target.result
      // Extract role from resume (simplified)
      const knownRoles = [
        "Frontend Developer",
        "Backend Developer",
        "Data Analyst",
        "Machine Learning Engineer",
        "Full Stack Developer",
        "DevOps Engineer",
        "UI/UX Designer",
        "Product Manager",
      ]
      role = knownRoles.find((r) => resumeData.includes(r)) || ""
      if (role) {
        roleInput.value = role
      }
    }
    reader.readAsText(file)
  }

  // Go to step 2
  function goToStep2() {
    const enteredRole = roleInput.value.trim()

    if (!resumeData && !enteredRole) {
      alert("Please upload a resume or enter a role.")
      return
    }

    if (enteredRole) {
      role = enteredRole
    }

    // Animate transition
    step1.classList.add("opacity-0", "translate-y-4")
    setTimeout(() => {
      step1.classList.add("hidden")
      step2.classList.remove("hidden")
      setTimeout(() => {
        step2.classList.remove("opacity-0", "translate-y-4")
      }, 50)
    }, 300)
  }

  // Start interview
  function startInterview() {
    difficulty = difficultySelect.value

    // Animate transition
    step2.classList.add("opacity-0", "translate-y-4")
    setTimeout(() => {
      step2.classList.add("hidden")
      chatSection.classList.remove("hidden")
      setTimeout(() => {
        chatSection.classList.remove("opacity-0", "translate-y-4")
        askFirstQuestion()
      }, 50)
    }, 300)
  }

  // Ask first question
  async function askFirstQuestion() {
    displayMessage(
      "Let's begin the interview. I'll be asking you questions related to your role as a " +
        role +
        ". Please provide detailed answers.",
      "bot",
    )

    // Show loading indicator
    const loadingMessage = document.createElement("div")
    loadingMessage.className =
      "p-3 rounded-lg bg-purple-100 dark:bg-purple-900/30 text-gray-800 dark:text-gray-200 self-start rounded-bl-none"
    loadingMessage.innerHTML = `
      <div class="flex items-start">
        <span class="text-xl mr-2">🤖</span>
        <div class="flex items-center">
          <span class="mr-2">Generating question</span>
          <div class="flex space-x-1">
            <div class="w-2 h-2 bg-purple-600 rounded-full animate-bounce"></div>
            <div class="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
            <div class="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
          </div>
        </div>
      </div>
    `
    chatBox.appendChild(loadingMessage)
    chatBox.scrollTop = chatBox.scrollHeight

    try {
      // Generate first question based on role and difficulty
      const response = await fetch("/api/interview", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "generate_interview_question",
          role: role,
          difficulty: difficulty,
          questionNumber: 1,
          previousQuestions: [],
          previousAnswers: [],
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate question")
      }

      const data = await response.json()
      currentQuestion = data.suggestion || "Tell me about your background and experience in this field."

      // Remove loading indicator
      chatBox.removeChild(loadingMessage)

      // Display the question
      displayMessage(currentQuestion, "bot")
      questionCount++
    } catch (error) {
      console.error("Error generating question:", error)

      // Remove loading indicator
      chatBox.removeChild(loadingMessage)

      // Fallback question if API fails
      currentQuestion = "Tell me about your background and experience in this field."
      displayMessage(currentQuestion, "bot")
      questionCount++
    }
  }

  // Submit answer
  async function submitAnswer() {
    const answer = answerInput.value.trim()
    if (!answer) return

    // Disable button during processing
    submitAnswerButton.disabled = true
    submitAnswerButton.innerHTML = `
        <svg class="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        Processing...
      `

    displayMessage(answer, "user")
    answerInput.value = ""

    chatHistory.push({ question: currentQuestion, answer })

    try {
      // Evaluate the answer
      const evaluationResponse = await fetch("/api/interview", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "evaluate_answer",
          role: role,
          difficulty: difficulty,
          question: currentQuestion,
          answer: answer,
        }),
      })

      if (!evaluationResponse.ok) {
        throw new Error("Failed to evaluate answer")
      }

      const evaluationData = await evaluationResponse.json()
      const feedback = evaluationData.suggestion || {}

      // Parse feedback (assuming it's returned as a JSON string or object)
      let parsedFeedback
      try {
        parsedFeedback = typeof feedback === "string" ? JSON.parse(feedback) : feedback
      } catch (e) {
        parsedFeedback = {
          score: Math.floor(Math.random() * 5) + 6, // Random score between 6-10 as fallback
          feedback: "Your answer was satisfactory.",
          strengths: ["Good communication"],
          areas_for_improvement: ["Could provide more specific examples"],
        }
      }

      // Store feedback for final report
      feedbackHistory.push({
        question: currentQuestion,
        answer: answer,
        feedback: parsedFeedback,
      })

      // Update total score
      totalScore += parsedFeedback.score || 0

      // Check if interview should end
      if (questionCount >= 5) {
        // End interview after 5 questions
        interviewComplete = true

        // Add generate summary button
        const summaryButtonContainer = document.createElement("div")
        summaryButtonContainer.className = "text-center mt-4"
        summaryButtonContainer.innerHTML = `
          <button id="generate-summary-btn" class="px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-md transition-colors">
            Generate Interview Summary
          </button>
        `
        chatBox.appendChild(summaryButtonContainer)

        // Add event listener to summary button
        document.getElementById("generate-summary-btn").addEventListener("click", generateSummary)

        // Re-enable submit button
        submitAnswerButton.disabled = true
        submitAnswerButton.textContent = "Interview Complete"

        return
      }

      // Generate next question
      const nextQuestionResponse = await fetch("/api/interview", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "generate_interview_question",
          role: role,
          difficulty: difficulty,
          questionNumber: questionCount + 1,
          previousQuestions: chatHistory.map((item) => item.question),
          previousAnswers: chatHistory.map((item) => item.answer),
        }),
      })

      if (!nextQuestionResponse.ok) {
        throw new Error("Failed to generate next question")
      }

      const nextQuestionData = await nextQuestionResponse.json()
      currentQuestion = nextQuestionData.suggestion || "Tell me about another aspect of your experience."

      // Display the next question
      displayMessage(currentQuestion, "bot")
      questionCount++
    } catch (err) {
      console.error("Error processing answer:", err)

      // Fallback to a generic follow-up question
      if (questionCount < 5) {
        currentQuestion = getGenericFollowUpQuestion(questionCount)
        displayMessage(currentQuestion, "bot")
        questionCount++
      } else {
        interviewComplete = true
        generateSummary()
      }
    } finally {
      // Re-enable button
      submitAnswerButton.disabled = false
      submitAnswerButton.textContent = "Submit Answer"
    }
  }

  // Get a generic follow-up question as fallback
  function getGenericFollowUpQuestion(questionNumber) {
    const genericQuestions = [
      "Can you describe a challenging project you've worked on and how you overcame obstacles?",
      "How do you stay updated with the latest technologies in your field?",
      "Tell me about a time when you had to work under pressure to meet a deadline.",
      "How do you handle conflicts or disagreements with team members?",
      "Where do you see yourself professionally in 5 years?",
    ]

    return genericQuestions[questionNumber % genericQuestions.length]
  }

  // Display message in chat
  function displayMessage(message, sender) {
    const messageDiv = document.createElement("div")
    messageDiv.className = `p-3 rounded-lg ${
      sender === "bot"
        ? "bg-purple-100 dark:bg-purple-900/30 text-gray-800 dark:text-gray-200 self-start rounded-bl-none"
        : "bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 self-end rounded-br-none ml-auto"
    }`

    messageDiv.innerHTML = `
        <div class="flex items-start">
          ${sender === "bot" ? '<span class="text-xl mr-2">🤖</span>' : '<span class="text-xl mr-2">👤</span>'}
          <div>${message}</div>
        </div>
      `

    // Set initial state for animation
    messageDiv.style.opacity = "0"
    messageDiv.style.transform = sender === "bot" ? "translateX(-10px)" : "translateX(10px)"

    chatBox.appendChild(messageDiv)

    // Trigger animation
    setTimeout(() => {
      messageDiv.style.opacity = "1"
      messageDiv.style.transform = "translateX(0)"
      messageDiv.style.transition = "opacity 0.3s ease, transform 0.3s ease"
    }, 50)

    chatBox.scrollTop = chatBox.scrollHeight
  }

  // Generate summary
  async function generateSummary() {
    // Show loading state in summary dashboard
    summaryDashboard.innerHTML = `
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 animate-fade-in">
        <h2 class="text-xl font-semibold mb-4">Generating Interview Summary</h2>
        <div class="flex justify-center items-center py-4">
          <svg class="w-10 h-10 animate-spin text-purple-600" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </div>
      </div>
    `

    try {
      // Generate comprehensive summary from chat history
      const summaryResponse = await fetch("/api/interview", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "generate_interview_summary",
          role: role,
          difficulty: difficulty,
          chatHistory: chatHistory,
          feedbackHistory: feedbackHistory,
          totalScore: totalScore,
          questionCount: questionCount,
        }),
      })

      if (!summaryResponse.ok) {
        throw new Error("Failed to generate summary")
      }

      const summaryData = await summaryResponse.json()
      const summary = summaryData.suggestion || {}

      // Parse summary
      let parsedSummary
      try {
        parsedSummary = typeof summary === "string" ? JSON.parse(summary) : summary
      } catch (e) {
        parsedSummary = {
          overallScore: Math.floor((totalScore / (questionCount * 10)) * 100),
          strengths: ["Good communication", "Ability to articulate technical concepts"],
          weaknesses: ["Could provide more specific examples", "Some answers lacked structure"],
          improvementAreas: ["Practice using the STAR method", "Prepare more concrete examples of past work"],
        }
      }

      // Display summary dashboard
      displaySummaryDashboard(parsedSummary)
    } catch (error) {
      console.error("Error generating summary:", error)

      // Fallback summary
      const fallbackSummary = {
        overallScore: Math.floor((totalScore / (questionCount * 10)) * 100),
        strengths: ["Good communication", "Ability to articulate technical concepts"],
        weaknesses: ["Could provide more specific examples", "Some answers lacked structure"],
        improvementAreas: ["Practice using the STAR method", "Prepare more concrete examples of past work"],
      }

      displaySummaryDashboard(fallbackSummary)
    }
  }

  // Display summary dashboard
  function displaySummaryDashboard(summary) {
    // Calculate score percentage
    const scorePercentage = summary.overallScore || Math.floor((totalScore / (questionCount * 10)) * 100)

    // Determine score color
    let scoreColor = "green"
    if (scorePercentage < 60) {
      scoreColor = "red"
    } else if (scorePercentage < 80) {
      scoreColor = "yellow"
    }

    summaryDashboard.innerHTML = `
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 animate-fade-in">
        <h2 class="text-xl font-semibold mb-4">🧠 Interview Summary</h2>
        
        <div class="mb-6">
          <div class="flex justify-between items-center mb-2">
            <h3 class="font-medium">Overall Performance</h3>
            <span class="text-${scoreColor}-600 font-bold">${scorePercentage}%</span>
          </div>
          <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
            <div class="bg-${scoreColor}-600 h-2.5 rounded-full" style="width: ${scorePercentage}%"></div>
          </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 class="font-medium mb-2 text-green-600">Strengths</h3>
            <ul class="list-disc pl-5 space-y-1">
              ${summary.strengths.map((strength) => `<li>${strength}</li>`).join("")}
            </ul>
          </div>
          
          <div>
            <h3 class="font-medium mb-2 text-red-600">Areas for Improvement</h3>
            <ul class="list-disc pl-5 space-y-1">
              ${summary.weaknesses.map((weakness) => `<li>${weakness}</li>`).join("")}
            </ul>
          </div>
        </div>
        
        <div class="mb-6">
          <h3 class="font-medium mb-2">Recommended Actions</h3>
          <ul class="list-disc pl-5 space-y-1">
            ${summary.improvementAreas.map((area) => `<li>${area}</li>`).join("")}
          </ul>
        </div>
        
        <button id="end-interview-btn" class="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700">
          View Detailed Report
        </button>
      </div>
    `

    // Add event listener to end interview button
    document.getElementById("end-interview-btn").addEventListener("click", endInterview)
  }

  // End interview and show report
  function endInterview() {
    // Animate transition
    chatSection.classList.add("opacity-0", "translate-y-4")
    summaryDashboard.classList.add("opacity-0", "translate-y-4")

    setTimeout(() => {
      chatSection.classList.add("hidden")
      summaryDashboard.innerHTML = ""
      reportSection.classList.remove("hidden")

      // Generate detailed report
      let reportText = `Interview Report for ${role} Position (${difficulty} difficulty)\n\n`
      reportText += `Total Score: ${totalScore} out of ${questionCount * 10}\n\n`

      reportText += "Question and Answer Summary:\n\n"

      feedbackHistory.forEach((item, index) => {
        reportText += `Question ${index + 1}: ${item.question}\n`
        reportText += `Your Answer: ${item.answer}\n`
        reportText += `Score: ${item.feedback.score}/10\n`
        reportText += `Feedback: ${item.feedback.feedback}\n`

        if (item.feedback.strengths && item.feedback.strengths.length > 0) {
          reportText += "Strengths:\n"
          item.feedback.strengths.forEach((strength) => {
            reportText += `- ${strength}\n`
          })
        }

        if (item.feedback.areas_for_improvement && item.feedback.areas_for_improvement.length > 0) {
          reportText += "Areas for Improvement:\n"
          item.feedback.areas_for_improvement.forEach((area) => {
            reportText += `- ${area}\n`
          })
        }

        reportText += "\n---\n\n"
      })

      reportText += "Overall Assessment:\n\n"

      // Calculate strengths and weaknesses from all feedback
      const allStrengths = new Set()
      const allWeaknesses = new Set()

      feedbackHistory.forEach((item) => {
        if (item.feedback.strengths) {
          item.feedback.strengths.forEach((s) => allStrengths.add(s))
        }
        if (item.feedback.areas_for_improvement) {
          item.feedback.areas_for_improvement.forEach((w) => allWeaknesses.add(w))
        }
      })

      reportText += "Strengths:\n"
      Array.from(allStrengths).forEach((strength) => {
        reportText += `- ${strength}\n`
      })

      reportText += "\nAreas for Improvement:\n"
      Array.from(allWeaknesses).forEach((weakness) => {
        reportText += `- ${weakness}\n`
      })

      reportText += "\nRecommendations:\n"
      reportText += "- Practice using the STAR method (Situation, Task, Action, Result)\n"
      reportText += "- Prepare more concrete examples of past work\n"
      reportText += "- Research more about industry trends for future interviews\n"

      reportContent.textContent = reportText

      setTimeout(() => {
        reportSection.classList.remove("opacity-0", "translate-y-4")
      }, 50)
    }, 300)
  }

  // Download report
  function downloadReport() {
    const content = reportContent.textContent
    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)

    const a = document.createElement("a")
    a.href = url
    a.download = `interview_report_${role.replace(/\s+/g, "_")}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Initialize
  init()
})
