document.addEventListener("DOMContentLoaded", () => {
  // RIASEC test questions
  const questions = [
    { id: 1, text: "I enjoy working with tools or machines.", type: "R" },
    { id: 2, text: "I like building or repairing things.", type: "R" },
    { id: 3, text: "I prefer outdoor work to office work.", type: "R" },
    { id: 4, text: "I enjoy working with animals or nature.", type: "R" },
    { id: 5, text: "I like driving or operating equipment.", type: "R" },
    { id: 6, text: "I enjoy physical, hands-on tasks.", type: "R" },
    { id: 7, text: "I like repairing electronic devices.", type: "R" },
    { id: 8, text: "I prefer practical tasks over theory.", type: "R" },
    { id: 9, text: "I enjoy assembling things myself.", type: "R" },
    { id: 10, text: "I would enjoy a job that keeps me active.", type: "R" },

    { id: 11, text: "I like solving puzzles or problems.", type: "I" },
    { id: 12, text: "I enjoy doing research or investigations.", type: "I" },
    { id: 13, text: "I enjoy learning about science and technology.", type: "I" },
    { id: 14, text: "I enjoy analyzing data or situations.", type: "I" },
    { id: 15, text: "I prefer working independently on problems.", type: "I" },
    { id: 16, text: "I enjoy thinking deeply about abstract concepts.", type: "I" },
    { id: 17, text: "I like using logic and reasoning.", type: "I" },
    { id: 18, text: "I am curious about how things work.", type: "I" },
    { id: 19, text: "I enjoy examining evidence.", type: "I" },
    { id: 20, text: "I enjoy tasks that challenge my intellect.", type: "I" },

    { id: 21, text: "I enjoy expressing myself through art.", type: "A" },
    { id: 22, text: "I enjoy writing stories or poems.", type: "A" },
    { id: 23, text: "I like creating music or performing.", type: "A" },
    { id: 24, text: "I like designing or decorating spaces.", type: "A" },
    { id: 25, text: "I enjoy photography or film.", type: "A" },
    { id: 26, text: "I prefer unstructured tasks that allow creativity.", type: "A" },
    { id: 27, text: "I enjoy brainstorming new ideas.", type: "A" },
    { id: 28, text: "I like drawing, sketching, or painting.", type: "A" },
    { id: 29, text: "I enjoy improvisation and experimentation.", type: "A" },
    { id: 30, text: "I like exploring different forms of self-expression.", type: "A" },

    { id: 31, text: "I enjoy helping people learn.", type: "S" },
    { id: 32, text: "I like volunteering for social causes.", type: "S" },
    { id: 33, text: "I enjoy working with children or elderly.", type: "S" },
    { id: 34, text: "I enjoy listening to others and offering support.", type: "S" },
    { id: 35, text: "I am drawn to counseling or therapy roles.", type: "S" },
    { id: 36, text: "I like mentoring or coaching others.", type: "S" },
    { id: 37, text: "I enjoy promoting health and wellness.", type: "S" },
    { id: 38, text: "I enjoy working in teams with a shared purpose.", type: "S" },
    { id: 39, text: "I enjoy resolving conflicts or misunderstandings.", type: "S" },
    { id: 40, text: "I like connecting people and building relationships.", type: "S" },

    { id: 41, text: "I enjoy taking the lead in group settings.", type: "E" },
    { id: 42, text: "I like selling ideas, products, or services.", type: "E" },
    { id: 43, text: "I enjoy negotiating and persuading others.", type: "E" },
    { id: 44, text: "I like managing projects or businesses.", type: "E" },
    { id: 45, text: "I am comfortable with taking risks.", type: "E" },
    { id: 46, text: "I enjoy public speaking.", type: "E" },
    { id: 47, text: "I prefer fast-paced, dynamic environments.", type: "E" },
    { id: 48, text: "I enjoy initiating new ventures.", type: "E" },
    { id: 49, text: "I like influencing or motivating others.", type: "E" },
    { id: 50, text: "I enjoy setting and achieving ambitious goals.", type: "E" },

    { id: 51, text: "I enjoy organizing files or data.", type: "C" },
    { id: 52, text: "I like creating spreadsheets or charts.", type: "C" },
    { id: 53, text: "I follow rules and procedures carefully.", type: "C" },
    { id: 54, text: "I enjoy doing routine clerical tasks.", type: "C" },
    { id: 55, text: "I like keeping things orderly and neat.", type: "C" },
    { id: 56, text: "I enjoy working with numbers and budgets.", type: "C" },
    { id: 57, text: "I prefer clear expectations and structure.", type: "C" },
    { id: 58, text: "I am good at following instructions.", type: "C" },
    { id: 59, text: "I enjoy tracking details and double-checking.", type: "C" },
    { id: 60, text: "I like working in an office environment.", type: "C" },
  ]

  let currentIndex = 0
  let scores = { R: 0, I: 0, A: 0, S: 0, E: 0, C: 0 }
  let answers = []
  let isSubmitting = false

  const testContainer = document.getElementById("test-container")
  const resultsContainer = document.getElementById("results-container")
  const questionCounter = document.getElementById("question-counter")
  const progressPercentage = document.getElementById("progress-percentage")
  const progressBar = document.getElementById("progress-bar")
  const questionText = document.getElementById("question-text")
  const answerSlider = document.getElementById("answer-slider")
  const prevButton = document.getElementById("prev-button")
  const nextButton = document.getElementById("next-button")
  const resultsContent = document.getElementById("results-content")
  const restartButton = document.getElementById("restart-button")
  const downloadButton = document.getElementById("download-button")

  // Initialize the test
  function initTest() {
    renderQuestion()

    // Event listeners
    prevButton.addEventListener("click", handlePrevious)
    nextButton.addEventListener("click", handleNext)
    restartButton.addEventListener("click", restartTest)
    downloadButton.addEventListener("click", downloadResults)
  }

  // Render the current question
  function renderQuestion() {
    const q = questions[currentIndex]
    questionText.textContent = q.text
    questionCounter.textContent = `Question ${currentIndex + 1} of ${questions.length}`

    const percent = ((currentIndex + 1) / questions.length) * 100
    progressPercentage.textContent = `${Math.round(percent)}% Complete`
    progressBar.style.width = `${percent}%`

    // Set slider value from previous answer if available
    if (answers[currentIndex]) {
      answerSlider.value = answers[currentIndex].value * 100
    } else {
      answerSlider.value = 50 // Default to middle
    }

    // Update button text for last question
    if (currentIndex === questions.length - 1) {
      nextButton.innerHTML = `
          Submit
          <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
          </svg>
        `
    } else {
      nextButton.innerHTML = `
          Next
          <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
          </svg>
        `
    }

    // Enable/disable previous button
    prevButton.disabled = currentIndex === 0
  }

  // Handle next button click
  function handleNext() {
    const q = questions[currentIndex]
    const value = Number.parseFloat(answerSlider.value) / 100

    // Update scores
    scores[q.type] += value

    // Save answer
    if (answers[currentIndex]) {
      answers[currentIndex].value = value
    } else {
      answers.push({ id: q.id, value, type: q.type })
    }

    if (currentIndex < questions.length - 1) {
      currentIndex++
      renderQuestion()
    } else {
      submitScores()
    }
  }

  // Handle previous button click
  function handlePrevious() {
    if (currentIndex > 0) {
      currentIndex--
      renderQuestion()
    }
  }

  // Submit scores to the API
  async function submitScores() {
    if (isSubmitting) return

    isSubmitting = true
    nextButton.disabled = true
    nextButton.innerHTML = `
        <svg class="w-4 h-4 mr-2 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        Submitting...
      `

    try {
      const response = await fetch("/api/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ scores }),
      })

      if (!response.ok) {
        throw new Error("Failed to submit scores")
      }

      const data = await response.json()
      showResults(data.suggestion || "No suggestion available.")
    } catch (error) {
      console.error("Error submitting scores:", error)
      showResults("An error occurred while generating your results. Please try again.")
    } finally {
      isSubmitting = false
      nextButton.disabled = false
    }
  }

  // Show results
  function showResults(suggestion) {
    testContainer.classList.add("hidden")
    resultsContainer.classList.remove("hidden")
    resultsContent.textContent = suggestion
  }

  // Restart the test
  function restartTest() {
    currentIndex = 0
    scores = { R: 0, I: 0, A: 0, S: 0, E: 0, C: 0 }
    answers = []

    resultsContainer.classList.add("hidden")
    testContainer.classList.remove("hidden")

    renderQuestion()
  }

  // Download results as PDF or text
  function downloadResults() {
    const text = resultsContent.textContent
    const blob = new Blob([text], { type: "text/plain" })
    const url = URL.createObjectURL(blob)

    const a = document.createElement("a")
    a.href = url
    a.download = "riasec_results.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Initialize the test
  initTest()
})
