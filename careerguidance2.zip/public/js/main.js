document.addEventListener("DOMContentLoaded", () => {
  // Initialize 3D model
  initStudentModel()

  // Populate features section
  populateFeatures()

  // Add scroll animations
  initScrollAnimations()
})

function initStudentModel() {
  const container = document.getElementById("student-model")
  if (!container) return

  // Set up scene
  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.1, 1000)
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })

  renderer.setSize(container.clientWidth, container.clientHeight)
  renderer.setPixelRatio(window.devicePixelRatio)
  container.appendChild(renderer.domElement)

  // Add lights
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
  scene.add(ambientLight)

  const spotLight = new THREE.SpotLight(0xffffff, 1)
  spotLight.position.set(10, 10, 10)
  spotLight.angle = 0.15
  spotLight.penumbra = 1
  scene.add(spotLight)

  const pointLight = new THREE.PointLight(0xffffff, 1)
  pointLight.position.set(-10, -10, -10)
  scene.add(pointLight)

  // Load 3D model
  const loader = new THREE.GLTFLoader()
  let model

  loader.load("/assets/3d/duck.glb", (gltf) => {
    model = gltf.scene
    scene.add(model)

    // Position and scale model
    model.position.set(0, 0, 0)
    const scale = Math.min(1, container.clientWidth / 500)
    model.scale.set(scale, scale, scale)
  })

  // Set up camera position
  camera.position.z = 5

  // Add orbit controls
  const controls = new THREE.OrbitControls(camera, renderer.domElement)
  controls.enableZoom = false
  controls.enablePan = false
  controls.autoRotate = true
  controls.autoRotateSpeed = 0.5

  // Handle window resize
  window.addEventListener("resize", () => {
    camera.aspect = container.clientWidth / container.clientHeight
    camera.updateProjectionMatrix()
    renderer.setSize(container.clientWidth, container.clientHeight)
  })

  // Animation loop
  let scrollY = 0
  window.addEventListener("scroll", () => {
    scrollY = window.scrollY
  })

  function animate() {
    requestAnimationFrame(animate)

    if (model) {
      // Rotate model based on scroll
      model.rotation.y = scrollY * 0.001

      // Add gentle floating animation
      model.position.y = Math.sin(Date.now() * 0.001) * 0.1
    }

    controls.update()
    renderer.render(scene, camera)
  }

  animate()
}

function populateFeatures() {
  const featuresSection = document.getElementById("features-section")
  if (!featuresSection) return

  const features = [
    {
      icon: "compass",
      title: "RIASEC Personality Test",
      description:
        "Discover your career interests based on the Holland Code assessment to find careers that match your personality.",
      link: "/riasec-test",
    },
    {
      icon: "bar-chart",
      title: "Skill Gap Analysis",
      description: "Identify the skills you have and the ones you need to develop for your desired career path.",
      link: "/skill-gap",
    },
    {
      icon: "users",
      title: "Mock Interviews",
      description: "Practice with AI-powered interview simulations tailored to your target industry and role.",
      link: "/mock-interview",
    },
    {
      icon: "brain",
      title: "AI Career Advisor",
      description: "Get personalized career recommendations based on your education, skills, and interests.",
      link: "/",
    },
    {
      icon: "lightbulb",
      title: "Learning Path Creator",
      description:
        "Get step-by-step guidance on courses, certifications, and experiences needed for your dream career.",
      link: "/",
    },
    {
      icon: "graduation-cap",
      title: "Job Finder",
      description: "Discover job opportunities that match your profile and career aspirations.",
      link: "/job-finder",
    },
  ]

  features.forEach((feature) => {
    const card = document.createElement("div")
    card.className =
      "bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"

    card.innerHTML = `
        <div class="h-12 w-12 rounded-lg bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center mb-4">
          <svg class="h-6 w-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <use href="#icon-${feature.icon}"></use>
          </svg>
        </div>
        <h3 class="text-xl font-semibold mb-2">${feature.title}</h3>
        <p class="text-gray-600 dark:text-gray-400 mb-4">${feature.description}</p>
        <a href="${feature.link}" class="inline-flex items-center text-purple-600 hover:underline">
          ${feature.link === "/" ? "Coming Soon" : "Explore Now"}
          <svg class="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
          </svg>
        </a>
      `

    featuresSection.appendChild(card)
  })

  // Add SVG icons to the document
  const iconsSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg")
  iconsSvg.style.display = "none"

  const icons = {
    compass:
      "M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3zm3.56 13.33l-3.56-3.56-3.56 3.56L7 14.89l3.56-3.56L7 7.78l1.44-1.44 3.56 3.56 3.56-3.56 1.44 1.44-3.56 3.56 3.56 3.56-1.44 1.43z",
    "bar-chart": "M4 19h16v2H4zm3-4h10v2H7zm-3-4h16v2H4zm3-4h10v2H7zM4 3h16v2H4z",
    users:
      "M12 4.354a4 4 0 110 5.292V4.354zM15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197L15 21zM13 7a4 4 0 11-8 0 4 4 0 018 0z",
    brain:
      "M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z",
    lightbulb:
      "M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z",
    "graduation-cap":
      "M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222",
  }

  for (const [id, path] of Object.entries(icons)) {
    const symbol = document.createElementNS("http://www.w3.org/2000/svg", "symbol")
    symbol.setAttribute("id", `icon-${id}`)
    symbol.setAttribute("viewBox", "0 0 24 24")

    const pathElement = document.createElementNS("http://www.w3.org/2000/svg", "path")
    pathElement.setAttribute("stroke-linecap", "round")
    pathElement.setAttribute("stroke-linejoin", "round")
    pathElement.setAttribute("stroke-width", "2")
    pathElement.setAttribute("d", path)

    symbol.appendChild(pathElement)
    iconsSvg.appendChild(symbol)
  }

  document.body.appendChild(iconsSvg)
}

function initScrollAnimations() {
  const statsSection = document.getElementById("stats-section")
  const featuresSection = document.getElementById("features-section")

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          if (entry.target === statsSection) {
            statsSection.querySelectorAll("div").forEach((card, index) => {
              setTimeout(() => {
                card.classList.add("opacity-100")
                card.classList.remove("opacity-0", "translate-y-4")
              }, index * 100)
            })
          } else if (entry.target === featuresSection) {
            featuresSection.querySelectorAll("div").forEach((card, index) => {
              setTimeout(() => {
                card.classList.add("opacity-100")
                card.classList.remove("opacity-0", "translate-y-4")
              }, index * 100)
            })
          }
        }
      })
    },
    { threshold: 0.1 },
  )

  if (statsSection) {
    statsSection.querySelectorAll("div").forEach((card) => {
      card.classList.add("opacity-0", "translate-y-4", "transition-all", "duration-500")
    })
    observer.observe(statsSection)
  }

  if (featuresSection) {
    featuresSection.querySelectorAll("div").forEach((card) => {
      card.classList.add("opacity-0", "translate-y-4", "transition-all", "duration-500")
    })
    observer.observe(featuresSection)
  }
}
