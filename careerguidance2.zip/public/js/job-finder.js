document.addEventListener("DOMContentLoaded", () => {
  // DOM elements
  const jobTitleInput = document.getElementById("job-title")
  const jobLocationInput = document.getElementById("job-location")
  const jobTypeSelect = document.getElementById("job-type")
  const remoteOnlyCheckbox = document.getElementById("remote-only")
  const searchButton = document.getElementById("search-button")
  const searchIcon = document.getElementById("search-icon")
  const loadingIcon = document.getElementById("loading-icon")
  const searchText = document.getElementById("search-text")
  const resultsSection = document.getElementById("results-section")
  const resultsCount = document.getElementById("results-count")
  const loadingResults = document.getElementById("loading-results")
  const noResults = document.getElementById("no-results")
  const jobsContainer = document.getElementById("jobs-container")
  const downloadButton = document.getElementById("download-button")

  // State
  let jobs = []
  let isLoading = false

  // Initialize
  function init() {
    // Check if there's a selected career from skill gap analysis
    const selectedCareer = sessionStorage.getItem("selectedCareer")
    if (selectedCareer) {
      jobTitleInput.value = selectedCareer
    }

    // Event listeners
    searchButton.addEventListener("click", searchJobs)
    downloadButton.addEventListener("click", downloadResults)
  }

  // Search jobs
  async function searchJobs() {
    const title = jobTitleInput.value.trim()
    const location = jobLocationInput.value.trim()
    const jobType = jobTypeSelect.value
    const remote = remoteOnlyCheckbox.checked

    if (!title && !location && !jobType) {
      alert("Please enter at least one search criteria")
      return
    }

    // Show loading state
    isLoading = true
    searchButton.disabled = true
    searchIcon.classList.add("hidden")
    loadingIcon.classList.remove("hidden")
    searchText.textContent = "Searching..."

    resultsSection.classList.remove("hidden")
    loadingResults.classList.remove("hidden")
    noResults.classList.add("hidden")
    jobsContainer.innerHTML = ""
    downloadButton.classList.add("hidden")

    try {
      const queryParams = new URLSearchParams({
        title,
        location,
        job_type: jobType,
        remote: remote.toString(),
      })

      const response = await fetch(`/api/jobs?${queryParams.toString()}`)

      if (!response.ok) {
        throw new Error("Failed to fetch job listings")
      }

      const data = await response.json()
      jobs = Array.isArray(data) ? data : []

      // Update results count
      resultsCount.textContent = `${jobs.length} Jobs Found`

      // Show/hide download button
      if (jobs.length > 0) {
        downloadButton.classList.remove("hidden")
      } else {
        downloadButton.classList.add("hidden")
      }

      // Render jobs
      renderJobs()
    } catch (error) {
      console.error("Error fetching jobs:", error)
      jobs = []
      resultsCount.textContent = "0 Jobs Found"
      noResults.classList.remove("hidden")
      jobsContainer.innerHTML = ""
      downloadButton.classList.add("hidden")
    } finally {
      // Reset loading state
      isLoading = false
      searchButton.disabled = false
      searchIcon.classList.remove("hidden")
      loadingIcon.classList.add("hidden")
      searchText.textContent = "Search Jobs"
      loadingResults.classList.add("hidden")
    }
  }

  // Modify the renderJobs function to show more details when a card is clicked
  function renderJobs() {
    jobsContainer.innerHTML = ""

    if (jobs.length === 0) {
      noResults.classList.remove("hidden")
      return
    }

    noResults.classList.add("hidden")

    jobs.forEach((job, index) => {
      const jobCard = document.createElement("div")
      jobCard.className =
        "bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow cursor-pointer mb-4"
      jobCard.setAttribute("data-job-index", index)

      jobCard.innerHTML = `
      <div class="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
        <div class="space-y-2">
          <h3 class="text-xl font-semibold">${job.job_title || "Untitled Position"}</h3>
          <div class="flex flex-wrap gap-y-2 gap-x-4 text-sm text-gray-500 dark:text-gray-400">
            ${
              job.employer_name
                ? `
              <div class="flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                </svg>
                <span>${job.employer_name}</span>
              </div>
            `
                : ""
            }
            ${
              job.job_location
                ? `
              <div class="flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
                <span>${job.job_location}</span>
              </div>
            `
                : ""
            }
            ${
              job.job_employment_type
                ? `
              <div class="flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span>${job.job_employment_type}</span>
              </div>
            `
                : ""
            }
            ${
              job.job_posted_at
                ? `
              <div class="flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                </svg>
                <span>Posted ${job.job_posted_at}</span>
              </div>
            `
                : ""
            }
          </div>
        </div>
        <div class="flex-shrink-0">
          <a href="${job.job_apply_link}" target="_blank" rel="noopener noreferrer" class="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 inline-flex items-center">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
            </svg>
            Apply
          </a>
        </div>
      </div>
    `

      // Add click event to show job details
      jobCard.addEventListener("click", (e) => {
        // Don't trigger if clicking on the apply button
        if (e.target.closest("a")) return

        showJobDetails(job)
      })

      jobsContainer.appendChild(jobCard)
    })
  }

  // Add a new function to show job details in a modal
  function showJobDetails(job) {
    // Create modal container
    const modalContainer = document.createElement("div")
    modalContainer.className = "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"

    // Create modal content
    const modalContent = document.createElement("div")
    modalContent.className =
      "bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"

    // Create modal header with company logo if available
    let logoHtml = ""
    if (job.employer_logo) {
      logoHtml = `
      <div class="w-16 h-16 rounded-lg overflow-hidden bg-white flex items-center justify-center">
        <img src="${job.employer_logo}" alt="${job.employer_name} logo" class="max-w-full max-h-full object-contain">
      </div>
    `
    }

    // Format job description with paragraphs
    const formattedDescription = job.job_description
      ? job.job_description.replace(/\n\n/g, "</p><p>").replace(/\n/g, "<br>")
      : "No description available"

    // Build the modal HTML
    modalContent.innerHTML = `
    <div class="p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-start">
      <div class="flex items-start gap-4">
        ${logoHtml}
        <div>
          <h2 class="text-2xl font-bold">${job.job_title || "Untitled Position"}</h2>
          <p class="text-lg text-gray-600 dark:text-gray-400">${job.employer_name || ""}</p>
        </div>
      </div>
      <button id="close-modal" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
        </svg>
      </button>
    </div>
    
    <div class="p-6">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        ${
          job.job_location
            ? `
          <div>
            <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-1">Location</h3>
            <p>${job.job_location}</p>
          </div>
        `
            : ""
        }
        
        ${
          job.job_employment_type
            ? `
          <div>
            <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-1">Employment Type</h3>
            <p>${job.job_employment_type}</p>
          </div>
        `
            : ""
        }
        
        ${
          job.job_posted_at
            ? `
          <div>
            <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-1">Posted</h3>
            <p>${job.job_posted_at}</p>
          </div>
        `
            : ""
        }
        
        ${
          job.employer_website
            ? `
          <div>
            <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-1">Company Website</h3>
            <a href="${job.employer_website}" target="_blank" class="text-purple-600 hover:underline">${job.employer_website}</a>
          </div>
        `
            : ""
        }
      </div>
      
      <div class="mb-6">
        <h3 class="text-lg font-semibold mb-2">Job Description</h3>
        <div class="text-gray-700 dark:text-gray-300 space-y-4">
          <p>${formattedDescription}</p>
        </div>
      </div>
      
      ${
        job.job_highlights && Object.keys(job.job_highlights).length > 0
          ? `
        <div class="mb-6">
          <h3 class="text-lg font-semibold mb-2">Highlights</h3>
          <div class="space-y-4">
            ${Object.entries(job.job_highlights)
              .map(
                ([key, values]) => `
              <div>
                <h4 class="font-medium capitalize">${key.replace(/_/g, " ")}</h4>
                <ul class="list-disc pl-5 mt-2">
                  ${Array.isArray(values) ? values.map((item) => `<li>${item}</li>`).join("") : ""}
                </ul>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      `
          : ""
      }
      
      <div class="flex justify-center">
        <a href="${job.job_apply_link}" target="_blank" rel="noopener noreferrer" class="px-6 py-3 bg-purple-600 text-white rounded-md hover:bg-purple-700 inline-flex items-center">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
          </svg>
          Apply for this position
        </a>
      </div>
    </div>
  `

    // Append modal to body
    modalContainer.appendChild(modalContent)
    document.body.appendChild(modalContainer)

    // Add event listener to close button
    document.getElementById("close-modal").addEventListener("click", () => {
      document.body.removeChild(modalContainer)
    })

    // Close modal when clicking outside
    modalContainer.addEventListener("click", (e) => {
      if (e.target === modalContainer) {
        document.body.removeChild(modalContainer)
      }
    })
  }

  // Download results
  function downloadResults() {
    if (jobs.length === 0) {
      alert("No jobs to download!")
      return
    }

    let content = "Job Listings\n\n"

    jobs.forEach((job, index) => {
      content += `Job ${index + 1}: ${job.title || "Untitled Position"}\n`
      if (job.company_name) content += `Company: ${job.company_name}\n`
      if (job.location) content += `Location: ${job.location}\n`
      if (job.job_type) content += `Type: ${job.job_type}\n`
      content += `Apply: ${job.url}\n\n`
    })

    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "job_listings.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Initialize
  init()
})
