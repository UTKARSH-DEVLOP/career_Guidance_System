document.addEventListener("DOMContentLoaded", () => {
  // Check if SpeechRecognition is supported
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
  const SpeechGrammarList = window.SpeechGrammarList || window.webkitSpeechGrammarList
  const SpeechRecognitionEvent = window.SpeechRecognitionEvent || window.webkitSpeechRecognitionEvent

  const isSpeechRecognitionSupported = !!SpeechRecognition
  const isSpeechSynthesisSupported = "speechSynthesis" in window

  // DOM elements
  const chatForm = document.getElementById("chat-form")
  const chatInput = document.getElementById("chat-input")
  const chatMessages = document.getElementById("chat-messages")
  const micButton = document.getElementById("mic-button")
  const micIcon = document.getElementById("mic-icon")
  const micListeningIcon = document.getElementById("mic-listening-icon")
  const speakButton = document.getElementById("speak-button")
  const speakIcon = document.getElementById("speak-icon")
  const speakMutedIcon = document.getElementById("speak-muted-icon")
  const sendButton = document.getElementById("send-button")

  // State
  let isListening = false
  let isSpeaking = true
  let recognition = null
  let currentUtterance = null

  // Initialize
  function init() {
    // Set up speech recognition if supported
    if (isSpeechRecognitionSupported) {
      recognition = new SpeechRecognition()
      recognition.continuous = false
      recognition.lang = "en-US"
      recognition.interimResults = false
      recognition.maxAlternatives = 1

      recognition.onresult = handleSpeechResult
      recognition.onerror = handleSpeechError
      recognition.onend = handleSpeechEnd

      micButton.classList.remove("hidden")
    }

    // Set up speech synthesis if supported
    if (isSpeechSynthesisSupported) {
      speakButton.classList.remove("hidden")
    }

    // Event listeners
    chatForm.addEventListener("submit", handleSubmit)
    micButton.addEventListener("click", toggleListening)
    speakButton.addEventListener("click", toggleSpeaking)

    // Add event listener for stopping speech when user starts typing
    chatInput.addEventListener("input", () => {
      if (currentUtterance && speechSynthesis.speaking) {
        speechSynthesis.cancel()
      }
    })
  }

  // Toggle speech recognition
  function toggleListening() {
    if (!isSpeechRecognitionSupported) return

    if (isListening) {
      stopListening()
    } else {
      startListening()
    }
  }

  // Start listening
  function startListening() {
    isListening = true
    micIcon.classList.add("hidden")
    micListeningIcon.classList.remove("hidden")
    micButton.classList.add("bg-red-500", "hover:bg-red-600")
    micButton.classList.remove("bg-gray-200", "dark:bg-gray-700", "hover:bg-gray-300", "dark:hover:bg-gray-600")

    try {
      recognition.start()
      chatInput.placeholder = "Listening..."
    } catch (error) {
      console.error("Error starting speech recognition:", error)
      stopListening()
    }
  }

  // Stop listening
  function stopListening() {
    isListening = false
    micIcon.classList.remove("hidden")
    micListeningIcon.classList.add("hidden")
    micButton.classList.remove("bg-red-500", "hover:bg-red-600")
    micButton.classList.add("bg-gray-200", "dark:bg-gray-700", "hover:bg-gray-300", "dark:hover:bg-gray-600")

    try {
      recognition.stop()
      chatInput.placeholder = "Type your message..."
    } catch (error) {
      console.error("Error stopping speech recognition:", error)
    }
  }

  // Handle speech recognition result
  function handleSpeechResult(event) {
    const transcript = event.results[0][0].transcript
    chatInput.value = transcript
    stopListening()

    // Auto-submit if confidence is high
    if (event.results[0][0].confidence > 0.8) {
      sendButton.click()
    }
  }

  // Handle speech recognition error
  function handleSpeechError(event) {
    console.error("Speech recognition error:", event.error)
    stopListening()
  }

  // Handle speech recognition end
  function handleSpeechEnd() {
    stopListening()
  }

  // Toggle speech synthesis
  function toggleSpeaking() {
    isSpeaking = !isSpeaking

    if (isSpeaking) {
      speakIcon.classList.remove("hidden")
      speakMutedIcon.classList.add("hidden")
    } else {
      speakIcon.classList.add("hidden")
      speakMutedIcon.classList.remove("hidden")

      // Stop any ongoing speech
      if (speechSynthesis.speaking) {
        speechSynthesis.cancel()
      }
    }
  }

  // Speak text
  function speakText(text) {
    if (!isSpeechSynthesisSupported || !isSpeaking) return

    // Stop any ongoing speech
    if (speechSynthesis.speaking) {
      speechSynthesis.cancel()
    }

    // Create utterance
    const utterance = new SpeechSynthesisUtterance(text)

    // Get voices
    const voices = speechSynthesis.getVoices()

    // Try to find a good English voice
    const preferredVoice =
      voices.find(
        (voice) => voice.lang.includes("en") && voice.name.includes("Google") && !voice.name.includes("Male"),
      ) ||
      voices.find((voice) => voice.lang.includes("en") && !voice.name.includes("Male")) ||
      voices[0]

    if (preferredVoice) {
      utterance.voice = preferredVoice
    }

    utterance.rate = 1.0
    utterance.pitch = 1.0

    // Store current utterance
    currentUtterance = utterance

    // Speak
    speechSynthesis.speak(utterance)
  }

  // Handle form submission
  async function handleSubmit(e) {
    e.preventDefault()

    const message = chatInput.value.trim()
    if (!message) return

    // Add user message to chat
    addMessage(message, "user")

    // Clear input
    chatInput.value = ""

    // Show loading indicator
    const loadingMessage = addMessage("Thinking...", "bot", true)

    try {
      // Send message to API
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message }),
      })

      if (!response.ok) {
        throw new Error("Failed to get response")
      }

      const data = await response.json()

      // Remove loading indicator
      chatMessages.removeChild(loadingMessage)

      // Add bot message to chat
      const botMessage = data.response || "I'm sorry, I couldn't process your request."
      addMessage(botMessage, "bot")

      // Speak the response
      speakText(botMessage)
    } catch (error) {
      console.error("Error getting response:", error)

      // Remove loading indicator
      chatMessages.removeChild(loadingMessage)

      // Add error message to chat
      addMessage("I'm sorry, something went wrong. Please try again.", "bot")
    }
  }

  // Add message to chat
  function addMessage(message, sender, isLoading = false) {
    const messageElement = document.createElement("div")
    messageElement.className = `p-3 rounded-lg mb-4 ${
      sender === "user" ? "bg-purple-100 dark:bg-purple-900/30 ml-auto" : "bg-gray-100 dark:bg-gray-800"
    } max-w-[80%]`

    if (isLoading) {
      messageElement.innerHTML = `
        <div class="flex items-center">
          <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce mr-1"></div>
          <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce mr-1" style="animation-delay: 0.2s"></div>
          <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
        </div>
      `
    } else {
      messageElement.textContent = message
    }

    chatMessages.appendChild(messageElement)

    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight

    return messageElement
  }

  // Initialize
  init()
})
