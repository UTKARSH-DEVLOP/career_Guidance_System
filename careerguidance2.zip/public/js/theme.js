// Check for saved theme preference or use device preference
const getThemePreference = () => {
  if (typeof localStorage !== "undefined" && localStorage.getItem("theme")) {
    return localStorage.getItem("theme")
  }
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
}

// Apply the theme
const setTheme = (theme) => {
  const root = document.documentElement
  if (theme === "dark") {
    root.classList.add("dark")
  } else {
    root.classList.remove("dark")
  }
  localStorage.setItem("theme", theme)
}

// Initialize theme
setTheme(getThemePreference())

// Set up theme toggle buttons
document.addEventListener("DOMContentLoaded", () => {
  const themeToggle = document.getElementById("theme-toggle")
  const mobileThemeToggle = document.getElementById("mobile-theme-toggle")

  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const currentTheme = localStorage.getItem("theme") || "light"
      const newTheme = currentTheme === "light" ? "dark" : "light"
      setTheme(newTheme)
    })
  }

  if (mobileThemeToggle) {
    mobileThemeToggle.addEventListener("click", () => {
      const currentTheme = localStorage.getItem("theme") || "light"
      const newTheme = currentTheme === "light" ? "dark" : "light"
      setTheme(newTheme)
    })
  }

  // Mobile menu toggle
  const mobileMenuButton = document.getElementById("mobile-menu-button")
  const mobileMenu = document.getElementById("mobile-menu")
  const menuIcon = document.getElementById("menu-icon")
  const closeIcon = document.getElementById("close-icon")

  if (mobileMenuButton && mobileMenu) {
    mobileMenuButton.addEventListener("click", () => {
      mobileMenu.classList.toggle("hidden")
      menuIcon.classList.toggle("hidden")
      closeIcon.classList.toggle("hidden")
    })
  }

  // Set current year in footer
  const currentYearElement = document.getElementById("current-year")
  if (currentYearElement) {
    currentYearElement.textContent = new Date().getFullYear()
  }

  // Navbar scroll effect
  const navbar = document.getElementById("navbar")
  if (navbar) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 10) {
        navbar.classList.add("bg-white/80", "dark:bg-gray-900/80", "backdrop-blur-md", "shadow-md", "py-2")
        navbar.classList.remove("bg-transparent", "py-4")
      } else {
        navbar.classList.remove("bg-white/80", "dark:bg-gray-900/80", "backdrop-blur-md", "shadow-md", "py-2")
        navbar.classList.add("bg-transparent", "py-4")
      }
    })
  }
})
